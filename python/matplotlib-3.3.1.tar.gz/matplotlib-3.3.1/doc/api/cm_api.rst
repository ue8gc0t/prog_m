*****************
``matplotlib.cm``
*****************

.. automodule:: matplotlib.cm
   :members:
   :undoc-members:
   :show-inheritance:
