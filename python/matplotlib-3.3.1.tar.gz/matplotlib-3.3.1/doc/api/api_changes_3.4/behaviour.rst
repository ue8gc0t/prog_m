Behaviour changes
-----------------
