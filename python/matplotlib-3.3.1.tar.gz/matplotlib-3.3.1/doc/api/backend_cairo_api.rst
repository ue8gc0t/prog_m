
:mod:`matplotlib.backends.backend_cairo`
========================================

.. automodule:: matplotlib.backends.backend_cairo
   :members:
   :undoc-members:
   :show-inheritance:
