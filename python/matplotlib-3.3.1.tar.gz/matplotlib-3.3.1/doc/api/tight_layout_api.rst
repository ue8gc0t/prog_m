***************************
``matplotlib.tight_layout``
***************************

.. automodule:: matplotlib.tight_layout
   :members:
   :undoc-members:
   :show-inheritance:
