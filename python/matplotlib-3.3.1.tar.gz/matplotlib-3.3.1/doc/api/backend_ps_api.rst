
:mod:`matplotlib.backends.backend_ps`
=====================================

.. automodule:: matplotlib.backends.backend_ps
   :members:
   :undoc-members:
   :show-inheritance:
