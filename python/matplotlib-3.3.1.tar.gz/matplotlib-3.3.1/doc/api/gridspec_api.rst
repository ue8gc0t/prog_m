***********************
``matplotlib.gridspec``
***********************

.. currentmodule:: matplotlib.gridspec

.. automodule:: matplotlib.gridspec
   :no-members:
   :no-inherited-members:

Classes
-------

.. autosummary::
   :toctree: _as_gen/
   :template: autosummary.rst

   GridSpec
   SubplotSpec
   GridSpecBase
   GridSpecFromSubplotSpec
