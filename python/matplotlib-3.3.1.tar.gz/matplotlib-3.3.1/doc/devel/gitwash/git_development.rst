.. _git-development:

=====================
 Git for development
=====================

Contents:

.. toctree::
   :maxdepth: 2

   forking_hell
   set_up_fork
   configure_git
   development_workflow
   maintainer_workflow
