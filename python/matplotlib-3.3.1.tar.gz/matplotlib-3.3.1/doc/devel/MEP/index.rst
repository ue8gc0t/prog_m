.. _MEP-index:

.. include:: README.rst

.. only:: html

   :Release: |version|
   :Date: |today|

.. toctree::
   :maxdepth: 1

   template

.. toctree::
   :glob:
   :maxdepth: 1

   MEP*
